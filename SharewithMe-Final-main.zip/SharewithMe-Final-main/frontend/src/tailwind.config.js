module.exports = {
    content: [
        'node_modules/preline/dist/*.js',
    ],
    plugins: [
        require('preline/plugin'),
    ],
}